package action.chart;

public class Element {
	// set a default
	String type = "bar";
	
	// the data values
	Object[] values;
    
    // Getters and setters follow
    public Object[] getValues() {
		return values;
	}
	public void setValues(Object[] values) {
		this.values = values;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
}
